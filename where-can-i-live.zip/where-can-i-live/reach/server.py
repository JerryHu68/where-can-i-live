"""The web app.  Run with:  python -m reach.server   then open http://localhost:8000

One JSON endpoint does the work. The page asks "arrive at this point by this
time" and gets back a grid of door-to-door minutes, one byte per cell. The
browser colours the grid itself, so dragging the max-commute slider never
needs another request.
"""

from __future__ import annotations

import base64
import os
import time
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

from .download import DEFAULT_DIR
from .gtfs import Timetable, format_time, load_timetable, parse_time
from .grid import NYC, Grid, commute_minutes, stations_near
from .places import PLACES
from .router import UNREACHABLE, latest_arrivals

STATIC_DIR = Path(__file__).resolve().parents[1] / "static"


def answer(tt: Timetable, grid: Grid, lat: float, lon: float, arrive: str, max_walk_min: float = 15) -> dict:
    """Everything the page needs for one question, as plain JSON-able data."""
    started = time.perf_counter()
    deadline = parse_time(arrive + ":00" if arrive.count(":") == 1 else arrive)
    targets = stations_near(tt, lat, lon, max_walk_min)
    latest = latest_arrivals(tt, targets, deadline)
    minutes = commute_minutes(grid, tt, latest, deadline, (lat, lon), max_walk_min)

    stations = [
        {
            "name": tt.station_names[s],
            "lat": tt.station_lats[s],
            "lon": tt.station_lons[s],
            "minutes": -(-(deadline - latest[s]) // 60),        # ceiling division
            "enter_by": format_time(latest[s]),
        }
        for s in range(len(latest)) if latest[s] != UNREACHABLE
    ]
    return {
        "destination": {"lat": lat, "lon": lon},
        "arrive": format_time(deadline),
        "day": tt.day,
        "service_date": tt.service_date.isoformat(),
        "grid": {
            "south": grid.south, "west": grid.west, "north": grid.north, "east": grid.east,
            "width": grid.width, "height": grid.height,
            "minutes": base64.b64encode(minutes.tobytes()).decode(),
        },
        "stations": stations,
        "stations_near_destination": len(targets),
        "compute_ms": round((time.perf_counter() - started) * 1000, 1),
    }


def create_app(feed_dir: str | Path | None = None) -> Flask:
    feed_dir = Path(feed_dir or os.environ.get("REACH_FEED", DEFAULT_DIR))
    app = Flask(__name__, static_folder=None)
    grid = Grid(*NYC)
    timetables: dict[str, Timetable] = {}          # one per kind of day, loaded on first use

    def timetable(day: str) -> Timetable:
        if day not in timetables:
            timetables[day] = load_timetable(feed_dir, day)
        return timetables[day]

    @app.get("/")
    def index():
        return send_from_directory(STATIC_DIR, "index.html")

    @app.get("/api/places")
    def places():
        return jsonify(PLACES)

    @app.get("/api/commute")
    def commute():
        try:
            lat = float(request.args["lat"])
            lon = float(request.args["lon"])
            arrive = request.args.get("arrive", "09:00")
            day = request.args.get("day", "weekday")
            walk = min(max(float(request.args.get("walk", 15)), 1), 30)
            parse_time(arrive + ":00")
            tt = timetable(day)
        except (KeyError, ValueError) as problem:
            return jsonify({"error": f"bad request: {problem}"}), 400
        except FileNotFoundError as problem:
            return jsonify({"error": str(problem)}), 503
        return jsonify(answer(tt, grid, lat, lon, arrive, walk))

    return app


if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=8000, debug=False)
