"""Download the MTA's subway schedule.  Run with:  python -m reach.download

The feed is published on https://www.mta.info/developers ("Regular GTFS").
It is a few MB zipped and is updated a few times a year.
"""

from __future__ import annotations

import io
import sys
import urllib.request
import zipfile
from pathlib import Path

FEED_URL = "https://rrgtfsfeeds.s3.amazonaws.com/gtfs_subway.zip"
DEFAULT_DIR = Path(__file__).resolve().parents[1] / "data" / "gtfs_subway"


def download(target: Path = DEFAULT_DIR, url: str = FEED_URL) -> Path:
    print(f"Downloading {url} ...")
    request = urllib.request.Request(url, headers={"User-Agent": "where-can-i-live"})
    with urllib.request.urlopen(request, timeout=60) as response:
        payload = response.read()
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        archive.extractall(target)
    print(f"Unpacked {len(payload) / 1e6:.1f} MB into {target}")
    return target


if __name__ == "__main__":
    download(Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_DIR)
