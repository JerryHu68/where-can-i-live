"""Command line.  Examples:

    python -m reach --to nyu-wsq --arrive 09:00
    python -m reach --to 40.8075,-73.9626 --arrive 08:30 --day saturday --within 45
    python -m reach --to nyu-wsq --png docs/nyu-9am.png
"""

from __future__ import annotations

import argparse

from .download import DEFAULT_DIR
from .gtfs import load_timetable
from .grid import NYC, Grid
from .places import PLACES
from .server import answer

BANDS = [15, 30, 45, 60, 90]


def main() -> None:
    parser = argparse.ArgumentParser(prog="reach", description="Where can I live and still arrive on time?")
    parser.add_argument("--to", required=True,
                        help="destination: 'lat,lon' or one of: " + ", ".join(p["id"] for p in PLACES))
    parser.add_argument("--arrive", default="09:00", help="deadline, HH:MM (default 09:00)")
    parser.add_argument("--day", default="weekday", choices=["weekday", "saturday", "sunday"])
    parser.add_argument("--within", type=int, default=30, help="list stations within this many minutes")
    parser.add_argument("--walk", type=float, default=15, help="longest walk to or from a station, minutes")
    parser.add_argument("--feed", default=str(DEFAULT_DIR), help="folder with the unzipped GTFS feed")
    parser.add_argument("--png", help="also save a map image to this path (needs matplotlib)")
    args = parser.parse_args()

    place = next((p for p in PLACES if p["id"] == args.to), None)
    if place:
        lat, lon, label = place["lat"], place["lon"], place["name"]
    else:
        lat, lon = (float(x) for x in args.to.split(","))
        label = f"({lat:.4f}, {lon:.4f})"

    tt = load_timetable(args.feed, args.day)
    result = answer(tt, Grid(*NYC), lat, lon, args.arrive, args.walk)

    best: dict[str, dict] = {}                      # some stations appear once per line; keep the best
    for s in result["stations"]:
        if s["name"] not in best or s["minutes"] < best[s["name"]]["minutes"]:
            best[s["name"]] = s
    stations = sorted(best.values(), key=lambda s: (s["minutes"], s["name"]))

    print(f"\nArrive at {label} by {result['arrive']} on a {args.day}")
    print(f"(timetable for {result['service_date']}, {len(tt.connections):,} train hops, "
          f"answered in {result['compute_ms']} ms)\n")
    print("Stations you could live near, counting the walk at the campus end:")
    previous = 0
    for band in BANDS:
        count = sum(previous < s["minutes"] <= band for s in stations)
        print(f"  {previous:>3}-{band:<3} min  {count:>4}  {'#' * (count // 4)}")
        previous = band

    print(f"\nWithin {args.within} minutes (walk into the station by the time shown):")
    for s in stations:
        if s["minutes"] <= args.within:
            print(f"  {s['minutes']:>3} min   by {s['enter_by']}   {s['name']}")

    if args.png:
        from .render import save_png
        save_png(result, args.feed, args.png, title=f"Arrive at {label} by {result['arrive']}, {args.day}")
        print(f"\nSaved {args.png}")


if __name__ == "__main__":
    main()
