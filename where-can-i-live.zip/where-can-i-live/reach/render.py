"""Static map image for the README and the --png flag. Needs matplotlib."""

from __future__ import annotations

import base64
import csv
import math
from collections import defaultdict
from pathlib import Path

import numpy as np

# Bands are coloured with the MTA's own line colours, quickest to slowest.
BAND_COLOURS = [(15, "#0039A6"), (30, "#00933C"), (45, "#FCCC0A"), (60, "#FF6319"), (90, "#EE352E")]


def save_png(result: dict, feed_dir: str | Path, path: str | Path, title: str = "") -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import to_rgba
    from matplotlib.patches import Patch

    g = result["grid"]
    minutes = np.frombuffer(base64.b64decode(g["minutes"]), dtype=np.uint8).reshape(g["height"], g["width"])

    image = np.zeros((g["height"], g["width"], 4))
    previous = 0
    for limit, colour in BAND_COLOURS:
        image[(minutes > previous) & (minutes <= limit)] = to_rgba(colour, 0.78)
        previous = limit

    fig, ax = plt.subplots(figsize=(10, 9.4), dpi=130)
    fig.patch.set_facecolor("#F3F1EC")
    ax.set_facecolor("#F3F1EC")
    ax.imshow(image, extent=(g["west"], g["east"], g["south"], g["north"]), interpolation="nearest", zorder=1)

    for line in _route_shapes(Path(feed_dir)):
        ax.plot(line[:, 1], line[:, 0], color="#1A1A1A", linewidth=0.45, alpha=0.55, zorder=2)

    dest = result["destination"]
    ax.scatter([dest["lon"]], [dest["lat"]], s=130, marker="*", color="white", edgecolor="black", linewidth=1.1, zorder=4)

    ax.set_xlim(-74.06, -73.72)
    ax.set_ylim(40.565, 40.91)
    ax.set_aspect(1 / math.cos(math.radians(40.73)))
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title(title, loc="left", fontsize=15, fontweight="bold", pad=12)

    labels, previous = [], 0
    for limit, colour in BAND_COLOURS:
        labels.append(Patch(facecolor=colour, alpha=0.78, label=f"{previous}-{limit} min"))
        previous = limit
    ax.legend(handles=labels, loc="upper left", frameon=True, facecolor="white", framealpha=0.95,
              title="Door to door", fontsize=10, title_fontsize=10)

    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)


def _route_shapes(feed_dir: Path) -> list[np.ndarray]:
    """Track geometry from shapes.txt, one polyline per shape, for context."""
    shapes_file = feed_dir / "shapes.txt"
    if not shapes_file.exists():
        return []
    points = defaultdict(list)
    with open(shapes_file, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            points[row["shape_id"]].append(
                (int(row["shape_pt_sequence"]), float(row["shape_pt_lat"]), float(row["shape_pt_lon"]))
            )
    longest = {}                                    # one shape per route+direction is plenty
    for shape_id, pts in points.items():
        key = shape_id.split(".")[0] + shape_id[-4:-3]
        if key not in longest or len(pts) > len(longest[key]):
            longest[key] = pts
    return [np.array([(lat, lon) for _, lat, lon in sorted(pts)]) for pts in longest.values()]
