"""A few destinations to start from. Click anywhere on the map to use your own."""

PLACES = [
    {"id": "nyu-wsq",    "name": "NYU, Washington Square", "lat": 40.7295, "lon": -73.9972},
    {"id": "nyu-tandon", "name": "NYU Tandon, MetroTech",  "lat": 40.6942, "lon": -73.9866},
    {"id": "columbia",   "name": "Columbia University",    "lat": 40.8075, "lon": -73.9626},
    {"id": "midtown",    "name": "Midtown, Bryant Park",   "lat": 40.7536, "lon": -73.9832},
    {"id": "fidi",       "name": "Financial District",     "lat": 40.7074, "lon": -74.0113},
]
