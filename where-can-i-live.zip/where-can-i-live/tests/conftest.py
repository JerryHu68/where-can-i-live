"""A toy transit system, written out as a real GTFS feed.

            R1
            |
            R2
            |
    B1--B2--B3        R3 and B3 are different stations joined by a
            :         4 minute passage (like Times Sq / Port Authority).
            R3
            |
            R4
            |
            R5

    RED    local,   R1..R5, 4 minutes per hop, every 10 minutes
    GREEN  express, R1 -> R3 -> R5, 6 minutes per hop, every 15 minutes
    BLUE   local,   B1..B3, 5 minutes per hop, every 12 minutes

Platforms are separate stops with a parent station, as in the MTA feed.
Saturday runs half as often. One Wednesday is a holiday running Sunday service.
"""

import csv
from datetime import date

import pytest

from reach import load_timetable

RED = ["R1", "R2", "R3", "R4", "R5"]
GREEN = ["R1", "R3", "R5"]
BLUE = ["B1", "B2", "B3"]
COORDS = {
    "R1": (40.7400, -74.0000), "R2": (40.7300, -74.0000), "R3": (40.7190, -74.0000),
    "R4": (40.7100, -74.0000), "R5": (40.7000, -74.0000),
    "B1": (40.7200, -74.0300), "B2": (40.7200, -74.0150), "B3": (40.7200, -74.0010),
}
TODAY = date(2026, 3, 2)          # a Monday inside the feed's validity


def hms(seconds: int) -> str:
    return f"{seconds // 3600:02d}:{seconds % 3600 // 60:02d}:{seconds % 60:02d}"


def write_feed(folder) -> None:
    def table(name, header, rows):
        with open(folder / name, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(header)
            writer.writerows(rows)

    stops = []
    for sid, (lat, lon) in COORDS.items():
        stops.append([sid, f"Station {sid}", lat, lon, 1, ""])
        for side in "NS":
            stops.append([sid + side, f"Station {sid}", lat, lon, "", sid])
    table("stops.txt", ["stop_id", "stop_name", "stop_lat", "stop_lon", "location_type", "parent_station"], stops)

    table("calendar.txt",
          ["service_id", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday", "start_date", "end_date"],
          [["Weekday", 1, 1, 1, 1, 1, 0, 0, "20260101", "20260630"],
           ["Saturday", 0, 0, 0, 0, 0, 1, 0, "20260101", "20260630"],
           ["Sunday", 0, 0, 0, 0, 0, 0, 1, "20260101", "20260630"]])
    table("calendar_dates.txt", ["service_id", "date", "exception_type"],
          [["Weekday", "20260304", 2], ["Sunday", "20260304", 1]])        # Wednesday 4 March is a holiday

    trips, stop_times = [], []

    def add_line(route, stations, hop, headway, service, side):
        start = 5 * 3600
        while start <= 24 * 3600 + 1800:                  # last trains leave after midnight
            trip_id = f"{service}-{route}-{side}-{start}"
            trips.append([route, trip_id, service])
            for k, station in enumerate(stations):
                t = start + k * hop
                stop_times.append([trip_id, station + side, hms(t), hms(t), k + 1])
            start += headway

    for service, factor in [("Weekday", 1), ("Saturday", 2), ("Sunday", 2)]:
        add_line("RED", RED, 240, 600 * factor, service, "S")
        add_line("RED", RED[::-1], 240, 600 * factor, service, "N")
        add_line("GREEN", GREEN, 360, 900 * factor, service, "S")
        add_line("GREEN", GREEN[::-1], 360, 900 * factor, service, "N")
        add_line("BLUE", BLUE, 300, 720 * factor, service, "S")
        add_line("BLUE", BLUE[::-1], 300, 720 * factor, service, "N")

    table("trips.txt", ["route_id", "trip_id", "service_id"], trips)
    table("stop_times.txt", ["trip_id", "stop_id", "arrival_time", "departure_time", "stop_sequence"], stop_times)

    transfers = [[s, s, 2, 180] for s in COORDS]          # 3 minutes to change trains in a station
    transfers += [["R3", "B3", 2, 240], ["B3", "R3", 2, 240]]
    table("transfers.txt", ["from_stop_id", "to_stop_id", "transfer_type", "min_transfer_time"], transfers)


@pytest.fixture(scope="session")
def feed_dir(tmp_path_factory):
    folder = tmp_path_factory.mktemp("toy_feed")
    write_feed(folder)
    return folder


@pytest.fixture(scope="session")
def tt(feed_dir):
    return load_timetable(feed_dir, "weekday", today=TODAY)
