import base64
from datetime import date

import numpy as np
import pytest

from reach import (
    NEVER, UNREACHABLE, Grid, commute_minutes, earliest_arrivals, format_time,
    latest_arrivals, load_timetable, parse_time, stations_near,
)
from reach.grid import distance_m, walk_seconds
from reach.server import create_app

from conftest import COORDS, TODAY


def T(text):                      # "08:42" -> seconds
    return parse_time(text + ":00")


# ---------------------------------------------------------------- loading

def test_times_past_midnight():
    assert parse_time("08:30:00") == 30600
    assert parse_time("25:10:00") == 90600          # 1:10am, still the same service day
    assert format_time(90600) == "01:10"


def test_platforms_collapse_into_stations(tt):
    assert sorted(tt.station_ids) == sorted(COORDS)  # R1N / R1S became R1
    assert all(0 <= c[2] < len(COORDS) and 0 <= c[3] < len(COORDS) for c in tt.connections)


def test_connections_are_sorted_and_sane(tt):
    assert tt.departures == sorted(tt.departures)
    assert all(arr >= dep for dep, arr, *_ in tt.connections)
    assert max(tt.departures) > 24 * 3600            # the feed really does run past midnight


def test_transfers_become_footpaths(tt):
    r3, b3 = tt.station_index("R3"), tt.station_index("B3")
    assert (r3, 180) in tt.footpaths_from[r3]        # change time inside a station
    assert (b3, 240) in tt.footpaths_from[r3]        # passage to the other station
    assert (r3, 240) in tt.footpaths_into[b3]


def test_weekday_skips_the_holiday(tt):
    # From Monday 2 March the next Wednesday is the 4th, a holiday on Sunday service.
    assert tt.service_date == date(2026, 3, 11)


def test_saturday_runs_fewer_trains(feed_dir, tt):
    saturday = load_timetable(feed_dir, "saturday", today=TODAY)
    assert saturday.service_date == date(2026, 3, 7)
    assert 0 < len(saturday.connections) < len(tt.connections)


def test_expired_feed_falls_back_to_its_last_valid_week(feed_dir):
    old = load_timetable(feed_dir, "weekday", today=date(2027, 1, 1))
    assert old.service_date == date(2026, 6, 24)


def test_missing_feed_says_how_to_fix_it(tmp_path):
    with pytest.raises(FileNotFoundError, match="reach.download"):
        load_timetable(tmp_path)


# ---------------------------------------------------------------- routing, checked by hand

def test_latest_arrivals_by_hand(tt):
    """Be at R5 by 09:00. Worked out on paper from the timetable in conftest."""
    latest = latest_arrivals(tt, {tt.station_index("R5"): 0}, T("09:00"))
    expect = {
        "R5": "09:00",
        "R4": "08:49",   # local leaves R4 08:52, minus 3 min to reach the platform
        "R3": "08:48",   # express leaves R3 08:51
        "R2": "08:41",   # local leaves R2 08:44
        "R1": "08:42",   # express leaves R1 08:45 and beats the 08:40 local
        "B3": "08:47",   # 4 min passage to R3, then the 08:51 express
        "B2": "08:38",   # blue leaves B2 08:41, reaches B3 08:46
        "B1": "08:33",
    }
    for station, time in expect.items():
        assert format_time(latest[tt.station_index(station)]) == time, station


def test_earliest_arrivals_by_hand(tt):
    arrival = earliest_arrivals(tt, {tt.station_index("R1"): 0}, T("08:00"))
    expect = {
        "R1": "08:00",
        "R2": "08:14",   # on the platform at 08:03, so the 08:10 local
        "R3": "08:18",
        "R5": "08:26",   # the local wins: the next express is not until 08:15
        "B3": "08:22",   # off at R3 08:18, 4 min passage
        "B1": "08:34",   # blue leaves B3 08:24
    }
    for station, time in expect.items():
        assert format_time(arrival[tt.station_index(station)]) == time, station


def test_walking_at_the_destination_end_counts(tt):
    r5 = tt.station_index("R5")
    plain = latest_arrivals(tt, {r5: 0}, T("09:00"))
    with_walk = latest_arrivals(tt, {r5: 300}, T("09:00"))       # 5 minute walk from R5
    assert with_walk[r5] == plain[r5] - 300
    assert all(a <= b for a, b in zip(with_walk, plain))


def test_after_midnight(tt):
    latest = latest_arrivals(tt, {tt.station_index("R5"): 0}, parse_time("24:30:00"))
    assert latest[tt.station_index("R1")] == parse_time("24:12:00")   # the 24:15 express


def test_nothing_is_reachable_before_the_first_train(tt):
    latest = latest_arrivals(tt, {tt.station_index("R5"): 0}, T("04:00"))
    assert latest[tt.station_index("R5")] == T("04:00")
    assert latest[tt.station_index("R1")] == UNREACHABLE
    assert earliest_arrivals(tt, {tt.station_index("R1"): 0}, parse_time("26:00:00"))[tt.station_index("R5")] == NEVER


# ---------------------------------------------------------------- routing, checked against itself

@pytest.mark.parametrize("deadline", ["06:07", "09:00", "12:34", "17:45", "23:59"])
@pytest.mark.parametrize("target", ["R5", "B1", "R2"])
def test_reverse_and_forward_searches_agree(tt, target, deadline):
    """The two searches share no code path, so they check each other.

    If `latest` says "walk into S by 08:42", then setting off from S at 08:42
    must arrive on time, and setting off one second later must not.
    """
    goal = tt.station_index(target)
    latest = latest_arrivals(tt, {goal: 0}, T(deadline))
    for s, t in enumerate(latest):
        if t == UNREACHABLE:
            continue
        assert earliest_arrivals(tt, {s: 0}, t)[goal] <= T(deadline)
        assert earliest_arrivals(tt, {s: 0}, t + 1)[goal] > T(deadline)


# ---------------------------------------------------------------- grid

def test_distance_and_walking_speed():
    assert distance_m(40.70, -74.0, 40.71, -74.0) == pytest.approx(1113.2, rel=1e-3)
    assert walk_seconds(1000) == pytest.approx(1000)     # 1.3 detour / 1.3 m/s cancel: 1 km = 1000 s


def test_grid_rows_follow_web_mercator():
    grid = Grid(40.49, -74.27, 40.92, -73.68, width=360)
    assert grid.lats[0] == pytest.approx(40.92) and grid.lats[-1] == pytest.approx(40.49)
    steps = -np.diff(grid.lats)
    assert steps[0] < steps[-1]                          # rows get taller in latitude going south
    assert grid.cell(50.0, -74.0) is None


def test_commute_grid(tt):
    grid = Grid(40.69, -74.04, 40.75, -73.99, width=200)
    dest = COORDS["R5"]
    deadline = T("09:00")
    latest = latest_arrivals(tt, stations_near(tt, *dest, max_walk_min=15), deadline)
    minutes = commute_minutes(grid, tt, latest, deadline, dest)

    assert minutes.dtype == np.uint8 and minutes.shape == (grid.height, grid.width)
    assert minutes[grid.cell(*dest)] <= 1                                # you are already there
    r1 = tt.station_index("R1")
    at_r1 = minutes[grid.cell(*COORDS["R1"])]
    assert 0 <= at_r1 - (deadline - latest[r1]) / 60 <= 2                # station time plus a few metres
    assert minutes[grid.cell(40.745, -74.035)] == 255                    # nowhere near a station


def test_stations_near(tt):
    near = stations_near(tt, *COORDS["R3"], max_walk_min=5)
    assert set(near) == {tt.station_index("R3"), tt.station_index("B3")}  # B3 is around the corner
    assert near[tt.station_index("R3")] == 0


# ---------------------------------------------------------------- HTTP API

@pytest.fixture(scope="module")
def client(feed_dir):
    return create_app(feed_dir).test_client()


def test_api_commute(client):
    lat, lon = COORDS["R5"]
    response = client.get(f"/api/commute?lat={lat}&lon={lon}&arrive=09:00&day=weekday")
    assert response.status_code == 200
    body = response.get_json()
    grid = body["grid"]
    cells = np.frombuffer(base64.b64decode(grid["minutes"]), dtype=np.uint8)
    assert cells.size == grid["width"] * grid["height"]
    assert body["stations_near_destination"] >= 1
    r1 = next(s for s in body["stations"] if s["name"] == "Station R1")
    assert r1["enter_by"] == "08:42" and r1["minutes"] == 18


def test_api_rejects_nonsense(client):
    assert client.get("/api/commute?lat=abc&lon=1").status_code == 400
    assert client.get("/api/commute?lat=40.7&lon=-74&arrive=banana").status_code == 400
    assert client.get("/api/commute?lat=40.7&lon=-74&day=funday").status_code == 400
    assert client.get("/api/commute").status_code == 400


def test_api_without_a_feed_explains_the_fix(tmp_path):
    response = create_app(tmp_path).test_client().get("/api/commute?lat=40.7&lon=-74")
    assert response.status_code == 503
    assert "reach.download" in response.get_json()["error"]


def test_page_and_places_are_served(client):
    assert client.get("/").status_code == 200
    assert len(client.get("/api/places").get_json()) >= 3
